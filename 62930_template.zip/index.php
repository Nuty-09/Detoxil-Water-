<!DOCTYPE html>
<html lang="ro" class="webp webp-alpha webp-animation webp-lossless">
  <head>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="assets/js/scroll.js"></script>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta name="theme-color" content="#ffffff" />
    <title>
      Cumpăraţi Detoxil water ieftin. Preţuri, Recenzii. Comandați Detoxil water
      acum!
    </title>
	
    <link rel="stylesheet" href="assets/css/style.min.css" />
    <script>
      !(function (e, n, A) {
        function o(e, n) {
          return typeof e === n;
        }

        function t() {
          var e, n, A, t, a, i, l;
          for (var f in r)
            if (r.hasOwnProperty(f)) {
              if (
                ((e = []),
                (n = r[f]),
                n.name &&
                  (e.push(n.name.toLowerCase()),
                  n.options && n.options.aliases && n.options.aliases.length))
              )
                for (A = 0; A < n.options.aliases.length; A++)
                  e.push(n.options.aliases[A].toLowerCase());
              for (
                t = o(n.fn, "function") ? n.fn() : n.fn, a = 0;
                a < e.length;
                a++
              )
                (i = e[a]),
                  (l = i.split(".")),
                  1 === l.length
                    ? (Modernizr[l[0]] = t)
                    : (!Modernizr[l[0]] ||
                        Modernizr[l[0]] instanceof Boolean ||
                        (Modernizr[l[0]] = new Boolean(Modernizr[l[0]])),
                      (Modernizr[l[0]][l[1]] = t)),
                  s.push((t ? "" : "no-") + l.join("-"));
            }
        }

        function a(e) {
          var n = u.className,
            A = Modernizr._config.classPrefix || "";
          if ((c && (n = n.baseVal), Modernizr._config.enableJSClass)) {
            var o = new RegExp("(^|\\s)" + A + "no-js(\\s|$)");
            n = n.replace(o, "$1" + A + "js$2");
          }
          Modernizr._config.enableClasses &&
            ((n += " " + A + e.join(" " + A)),
            c ? (u.className.baseVal = n) : (u.className = n));
        }

        function i(e, n) {
          if ("object" == typeof e) for (var A in e) f(e, A) && i(A, e[A]);
          else {
            e = e.toLowerCase();
            var o = e.split("."),
              t = Modernizr[o[0]];
            if ((2 == o.length && (t = t[o[1]]), "undefined" != typeof t))
              return Modernizr;
            (n = "function" == typeof n ? n() : n),
              1 == o.length
                ? (Modernizr[o[0]] = n)
                : (!Modernizr[o[0]] ||
                    Modernizr[o[0]] instanceof Boolean ||
                    (Modernizr[o[0]] = new Boolean(Modernizr[o[0]])),
                  (Modernizr[o[0]][o[1]] = n)),
              a([(n && 0 != n ? "" : "no-") + o.join("-")]),
              Modernizr._trigger(e, n);
          }
          return Modernizr;
        }
        var s = [],
          r = [],
          l = {
            _version: "3.6.0",
            _config: {
              classPrefix: "",
              enableClasses: !0,
              enableJSClass: !0,
              usePrefixes: !0,
            },
            _q: [],
            on: function (e, n) {
              var A = this;
              setTimeout(function () {
                n(A[e]);
              }, 0);
            },
            addTest: function (e, n, A) {
              r.push({
                name: e,
                fn: n,
                options: A,
              });
            },
            addAsyncTest: function (e) {
              r.push({
                name: null,
                fn: e,
              });
            },
          },
          Modernizr = function () {};
        (Modernizr.prototype = l), (Modernizr = new Modernizr());
        var f,
          u = n.documentElement,
          c = "svg" === u.nodeName.toLowerCase();
        !(function () {
          var e = {}.hasOwnProperty;
          f =
            o(e, "undefined") || o(e.call, "undefined")
              ? function (e, n) {
                  return n in e && o(e.constructor.prototype[n], "undefined");
                }
              : function (n, A) {
                  return e.call(n, A);
                };
        })(),
          (l._l = {}),
          (l.on = function (e, n) {
            this._l[e] || (this._l[e] = []),
              this._l[e].push(n),
              Modernizr.hasOwnProperty(e) &&
                setTimeout(function () {
                  Modernizr._trigger(e, Modernizr[e]);
                }, 0);
          }),
          (l._trigger = function (e, n) {
            if (this._l[e]) {
              var A = this._l[e];
              setTimeout(function () {
                var e, o;
                for (e = 0; e < A.length; e++) (o = A[e])(n);
              }, 0),
                delete this._l[e];
            }
          }),
          Modernizr._q.push(function () {
            l.addTest = i;
          }),
          Modernizr.addAsyncTest(function () {
            function e(e, n, A) {
              function o(n) {
                var o = n && "load" === n.type ? 1 == t.width : !1,
                  a = "webp" === e;
                i(e, a && o ? new Boolean(o) : o), A && A(n);
              }
              var t = new Image();
              (t.onerror = o), (t.onload = o), (t.src = n);
            }
            var n = [
                {
                  uri: "data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=",
                  name: "webp",
                },
                {
                  uri: "data:image/webp;base64,UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAABBxAR/Q9ERP8DAABWUDggGAAAADABAJ0BKgEAAQADADQlpAADcAD++/1QAA==",
                  name: "webp.alpha",
                },
                {
                  uri: "data:image/webp;base64,UklGRlIAAABXRUJQVlA4WAoAAAASAAAAAAAAAAAAQU5JTQYAAAD/////AABBTk1GJgAAAAAAAAAAAAAAAAAAAGQAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcA",
                  name: "webp.animation",
                },
                {
                  uri: "data:image/webp;base64,UklGRh4AAABXRUJQVlA4TBEAAAAvAAAAAAfQ//73v/+BiOh/AAA=",
                  name: "webp.lossless",
                },
              ],
              A = n.shift();
            e(A.name, A.uri, function (A) {
              if (A && "load" === A.type)
                for (var o = 0; o < n.length; o++) e(n[o].name, n[o].uri);
            });
          }),
          t(),
          a(s),
          delete l.addTest,
          delete l.addAsyncTest;
        for (var p = 0; p < Modernizr._q.length; p++) Modernizr._q[p]();
        e.Modernizr = Modernizr;
      })(window, document);
    </script>
    <style>
      .ever-popup-build {
        position: fixed;
        opacity: 0;
        z-index: -1;
        top: 0;
        left: -9999px;
      }
    </style>
    <style>
      .ever-popup__body.ever-mobile {
        display: none;
      }
      .ever-popup {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 111;
        display: none;
        overflow: auto;
      }
      .ever-popup__body {
        position: static;
        float: none;
        display: block;
        margin: 0 auto;
        width: auto;
      }
      .ever-popup.show {
        display: block;
        align-items: center;
      }
      .ever-popup__inner {
        position: relative;
        margin: 0 auto;
        padding-top: 35px;
      }
      .ever-popup__close {
        width: 35px;
        height: 30px;
        position: absolute;
        cursor: pointer;
        top: 0;
        right: 0;
        z-index: 1;
        -webkit-transition: 0.3s;
        -moz-transition: 0.3s;
        -ms-transition: 0.3s;
        -o-transition: 0.3s;
        transition: 0.3s;
      }
      .ever-popup__close:after,
      .ever-popup__close:before {
        content: "";
        position: absolute;
        right: 0;
        top: 10px;
        width: 35px;
        height: 10px;
        background: #fff;
        transition: all 1s;
      }
      .ever-popup__close:after {
        -webkit-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
        transform: rotate(-45deg);
      }
      .ever-popup__close:before {
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -o-transform: rotate(45deg);
        transform: rotate(45deg);
      }
      @media screen and (min-width: 1000px) {
        .ever-popup__body.ever-desktop {
          display: none;
        }
        .ever-popup__body.ever-mobile {
          display: block;
        }
      }
    </style>

     <!-- INTH_SNIPPET_TOP --></head>

  <body class="timer-different ev-date">
    <div class="header">
      <div class="container">
        <div class="header__menu">
          <img src="assets/images/menu.png" alt="menu" width="24" height="24" />
        </div>
        <div class="header__overlay"></div>
        <div class="header__menu-open">
          <div class="header__menu-open-content">
            <div class="close">
              <img src="assets/images/close.png" alt="X" width="35" height="35" />
            </div>
            <img
              class="menu-logo"
              src="assets/images/logo.png"
              alt="logo"
              width="165"
              height="23"
            />
            <ul class="header__list">
              <li class="header__list--li">
                <a class="close-menu link-down" href="#rew"
                  ><img
                    src="assets/images/nav1.png"
                    alt="header"
                    width="35"
                    height="35"
                  />
                  <p><span>Comentarii</span></p>
                </a>
              </li>
              <li class="header__list--li">
                <a class="close-menu link-down" href="#order"
                  ><img
                    src="assets/images/nav2.png"
                    alt="header"
                    width="30"
                    height="35"
                  />
                  <p><span>Cum să comandați</span></p>
                </a>
              </li>
            </ul>
            <div class="attention__timer timer">
              <span class="timer__text"
                >Până la sfârșitul promoţiei au rămas:</span
              >
              <div class="timer__block">
                <div class="timer__hours">
                  <span class="hours">0</span><span class="hours">0</span>
                </div>
                <span class="timer__dots">:</span>
                <div class="timer__minutes">
                  <span class="minutes">2</span><span class="minutes">7</span>
                </div>
                <span class="timer__dots">:</span>
                <div class="timer__seconds">
                  <span class="seconds">0</span><span class="seconds">0</span>
                </div>
              </div>
            </div>
            <div class="header__btn">
              <button class="btn header__btn--btn ever-popup-btn">
                Comandaţi un apel
              </button>
            </div>
          </div>
        </div>
        <div class="header__logo desktop">
          <img src="assets/images/logo.png" alt="logo" width="165" height="23" />
        </div>
        <ul class="header__list desktop">
          <li class="header__list--li">
            <a class="link-down" href="#rew"
              ><img src="assets/images/nav1.png" alt="nav" width="35" height="35" />
              <p><span>Recenze</span></p>
            </a>
          </li>
          <li class="header__list--li">
            <a class="link-down" href="#order"
              ><img src="assets/images/nav2.png" alt="nav" width="30" height="35" />
              <p><span>Jak objednat</span></p>
            </a>
          </li>
        </ul>
        <div class="header__timer--desk desktop">
          <div class="attention__timer timer">
            <span class="timer__text"
              >Până la sfârșitul promoţiei au rămas:</span
            >
            <div class="timer__block">
              <div class="timer__hours">
                <span class="hours">0</span><span class="hours">0</span>
              </div>
              <span class="timer__dots">:</span>
              <div class="timer__minutes">
                <span class="minutes">2</span><span class="minutes">7</span>
              </div>
              <span class="timer__dots">:</span>
              <div class="timer__seconds">
                <span class="seconds">0</span><span class="seconds">0</span>
              </div>
            </div>
          </div>
        </div>
        <div class="header__btn desktop">
          <button class="btn header__btn--btn ever-popup-btn">
            Comandaţi un apel
          </button>
        </div>
      </div>
    </div>
    <section class="first-block promo block">
      <div class="container">
        <h1 class="promo__title--mob">Detoxil water</h1>
        <h3 class="promo__subtitle--mob">
          Distruge toate tipurile de helminți și elimină toxinele din organism
        </h3>
        <div class="promo__cont">
          <div class="promo__man">
            <picture>
              <source media="(max-width:1023px)" "assets/images/dot.png" />
              <source type="image/webp" "assets/images/promo-people.webp" />
              <img
                src="assets/images/promo-people.png"
                alt="family"
                width="818"
                height="602"
              />
            </picture>
          </div>
          <div class="promo__description">
            <h1 class="promo__title">Detoxil water</h1>
            <h3 class="promo__subtitle">
              Distruge toate tipurile de helminți și elimină toxinele din
              organism
            </h3>
            <ul class="promo__list">
              <li class="promo__list-item">
                <span class="promo__list-item_weight"
                  ><b>Potrivit </b>pentru curățarea complexă a helminților și
                  prevenirea</span
                >
              </li>
              <li class="promo__list-item">
                <span class="promo__list-item_weight"
                  ><b>Sigur </b>și 100% remediu natural</span
                >
              </li>
              <li class="promo__list-item">
                <span class="promo__list-item_weight"
                  ><b>Eficacitatea </b>este dovedită clinic</span
                >
              </li>
            </ul>
            <p class="promo__pack">Fără efecte secundare</p>
            <div class="promo__medals">
              <img
                loading="lazy"
                src="assets/images/promo-sign1.png"
                alt="medal"
                width="105"
                height="83"
              /><img
                loading="lazy"
                src="assets/images/promo-sign2.png"
                alt="medal"
                width="85"
                height="85"
              /><img
                loading="lazy"
                src="assets/images/promo-sign3.png"
                alt="medal"
                width="92"
                height="84"
              />
            </div>
            <div class="product">
              <picture>
                <img
                  src="assets/images/product.png"
                  alt="product"
                  width="358"
                  height="409"
                />
              </picture>
              <div class="product__before animation__choice">
                <img
                  src="assets/images/choice.png"
                  alt="medal"
                  width="106"
                  height="106"
                />
              </div>
            </div>
          </div>
          <div class="promo__form">
            <div class="form">
              <h2 class="form__title">
                Numai astăzi<br /><span
                  class="form__title_color date-0"
                  data-format="dd monthFull"
                  >31 Августа</span
                >
              </h2>
              <div>
                Începutul promoției <span class="date-30">29.11.2020</span>
              </div>
              <div>
                Promoția se termină <span class="date-0">30.11.2020</span>
              </div><br>
              <div class="form__price">
                <div class="form__price-val">
                  <h5 class="form__price-title old-price">Prețul vechi</h5>
                  <p class="form__price-before">
                    <span
                      class="x_price_previous price_old form__price-before_line"
                      >318 RON</span
                    >
                  </p>
                </div>
                <div class="form_before"></div>
                <div class="form__price-val">
                  <h5 class="form__price-title new-price">Prețul nou</h5>
                  <p class="form__price-after">
                    <span class="x_price_current price_main">159 RON</span>
                  </p>
                </div>
              </div>


              <form     class="   orderForm   x_order_form cpa__order_form form__cont" method="post">

			  <div class="form__input-wrap"> <label class="form__input-icon">
                    <img alt="name" height="23" loading="lazy" src="assets/images/name.png" width="19"/>
                  </label>
                  <input aria-label="name" class="form__input" name="name" placeholder="Numele meu" required="" type="text"/>
                </div>
                <div class="form__input-wrap">
                  <label class="form__input-icon">
                    <img alt="phone" height="23" loading="lazy" src="assets/images/phone.svg" width="19"/>
                  </label>
                  <input aria-label="phone" class="form__input" name="phone"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5"     placeholder="Telefonul meu" required="" type="tel"/>
                </div>
                <div class="form__wrapper-btn">
                  <button class="btn form__btn pulse" type="submit">Comandaţi<br/>
                    <span class="btn_size">cu reducere</span>
                  </button>
                </div>
                <div class="nw">
                  <img src="assets/images/delivery2.png" style="max-width: 45px; width: 100%"/>
                  <span>Privind costu livrării, va adresați la consultant</span>
                </div>
              </form>


            </div>
            <div class="form-pay">
              <div class="form-pay__text online-people">
                <img
                  class="online-img"
                  loading="lazy"
                  src="assets/images/eye.png"
                  alt="eye"
                  width="20"
                  height="13"
                />
                <p>
                  acum, pe site-ul
                  <span class="text-bold online-dynamic">30</span> de persoane
                </p>
              </div>
              <div class="form-pay__text online-sold">
                <img
                  class="online-img"
                  loading="lazy"
                  src="assets/images/eye.png"
                  alt="eye"
                  width="20"
                  height="13"
                />
                <p><span class="text-bold">116</span> vânzări în ultima oră</p>
              </div>
            </div>
            <p class="form__privacy">
              Atenție! Au rămas
              <span class="color-red text-bold lastpack">80</span> de pachete.
            </p>
          </div>
        </div>
      </div>
    </section>
    <section class="statistics block">
      <div class="container">
        <h2 class="statistics__title title">Statistici periculoase</h2>
        <div class="statistics__wrap">
          <div class="statistics__left">
            <picture>
              <source type="image/webp" "assets/images/statistics.webp" />
              <img
                loading="lazy"
                src="assets/images/statistics.jpg"
                alt="statistics"
                width="500"
                height="360"
              /> </picture
            ><img
              class="statistics__zoom"
              loading="lazy"
              src="assets/images/statistics_zoom.png"
              alt="zoom"
              width="156"
              height="142"
            />
          </div>
          <div class="statistics__right">
            <div class="statistics__desc">
              <p class="statistics__text">
                Oamenii trebuie să se teamă de
                <span class="text-bold">400 de specii de helminți</span>.
                Aceștia intră în organism prin pește, carne, legume, fructe,
                vase, produse de îngrijire personală, apă, nisip, mâini murdare,
                animale de companie.
              </p>
              <p class="statistics__text">
                Paraziților nu le pasă ce sex, vârstă sau ce statut social
                aveți.
              </p>
            </div>
            <p class="statistics__main text-bold">
              Potrivit statisticilor, mai mult de 74% din omenire a fost
              infectată de ei
            </p>
            <p class="statistics__tex">
              Mulți oameni trăiesc cu paraziți
              <span class="text-bold"
                >de ani de zile și nici măcar nu știu despre asta.</span
              >
            </p>
          </div>
        </div>
      </div>
    </section>
    <div class="main block">
      <div class="container">
        <h2 class="main__ttl">
          Paraziții sunt una dintre cele mai periculoase și mai frecvente boli
          ale <span class="color">secolului XXI</span>!
        </h2>
      </div>
    </div>
    <section class="symptoms block">
      <div class="container">
        <h2 class="symptoms__title title">Credeţi că nu aveţi paraziți?</h2>
        <p class="symptoms__desc">Testați-vă</p>
        <div class="symptoms__wrap">
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-1.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-1.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Reacții alergice</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-2.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-2.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Oboseala cronică</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-3.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-3.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Dureri de cap frecvente</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-4.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-4.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Dureri abdominale și hipocondriale</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-5.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-5.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">
              Tulburări ale apetitului, constipație, diaree
            </p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-6.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-6.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Dureri articulare și musculare</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-7.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-7.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Anxietate, stres, somn rău</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/symptom-8.webp" />
                <img
                  loading="lazy"
                  src="assets/images/symptom-8.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Căderea părului, fragilitatea unghiilor</p>
          </div>
        </div>
      </div>
    </section>
    <section class="soon block bg-grey">
      <div class="container">
        <h2 class="title soon__title">
          De ce trebuie să scăpaţi de paraziți cât mai curând posibil?
        </h2>
        <div class="soon__slider">
          <div class="soon__slider-item">
            <div class="soon__slider-item--img-wrapper">
              <picture>
                <source type="image/webp" "assets/images/soon1.webp" />
                <img
                  class="soon__slider-item--img"
                  src="assets/images/soon1.png"
                  alt="reason"
                  width="370"
                  height="220"
                />
              </picture>
            </div>
            <p class="soon__slider-item--text">
              80% din toate bolile sunt cauzate direct sau indirect de paraziți
            </p>
          </div>
          <div class="soon__slider-item">
            <div class="soon__slider-item--img-wrapper">
              <picture>
                <source type="image/webp" "assets/images/soon2.webp" />
                <img
                  class="soon__slider-item--img"
                  src="assets/images/soon2.png"
                  alt="reason"
                  width="370"
                  height="220"
                />
              </picture>
            </div>
            <p class="soon__slider-item--text">
              Sistemul imunitar nu se descurcă cu funcțiile sale
            </p>
          </div>
          <div class="soon__slider-item">
            <div class="soon__slider-item--img-wrapper">
              <picture>
                <source type="image/webp" "assets/images/soon3.webp" />
                <img
                  class="soon__slider-item--img"
                  src="assets/images/soon3.png"
                  alt="reason"
                  width="370"
                  height="220"
                />
              </picture>
            </div>
            <p class="soon__slider-item--text">
              Helminții absorb oligoelemente și substanțe nutritive
            </p>
          </div>
          <div class="soon__slider-item">
            <div class="soon__slider-item--img-wrapper">
              <picture>
                <source type="image/webp" "assets/images/soon4.webp" />
                <img
                  class="soon__slider-item--img"
                  src="assets/images/soon4.png"
                  alt="reason"
                  width="370"
                  height="220"
                />
              </picture>
            </div>
            <p class="soon__slider-item--text">
              Paraziții distrug organele interne
            </p>
          </div>
          <div class="soon__slider-item">
            <div class="soon__slider-item--img-wrapper">
              <picture>
                <source type="image/webp" "assets/images/soon5.webp" />
                <img
                  class="soon__slider-item--img"
                  src="assets/images/soon5.png"
                  alt="reason"
                  width="370"
                  height="220"
                />
              </picture>
            </div>
            <p class="soon__slider-item--text">
              Activitatea paraziților provoacă reacții alergice
            </p>
          </div>
          <div class="soon__slider-item">
            <div class="soon__slider-item--img-wrapper">
              <picture>
                <source type="image/webp" "assets/images/soon6.webp" />
                <img
                  class="soon__slider-item--img"
                  src="assets/images/soon6.png"
                  alt="reason"
                  width="370"
                  height="220"
                />
              </picture>
            </div>
            <p class="soon__slider-item--text">
              Helminții eliberează toxine care dăunează întregului organism
            </p>
          </div>
        </div>
      </div>
    </section>
    <section class="about block">
      <div class="container">
        <h2 class="title about__title">
          Cu <span class="color-red">Detoxil water</span>, paraziții vor înceta
          să vă otrăvească corpul și să vă suprime imunitatea
        </h2>
        <div class="about-content">
          <ul class="about-list">
            <li class="about-list__item">
              <strong>Distruge tot felul de paraziți și larvele lor.</strong>
              Energia și sănătatea vă vor reveni. Starea pielii, părului și
              unghiilor se va îmbunătăți.
            </li>
            <li class="about-list__item">
              <strong>Elimină toxinele. </strong> Veți uita de dureri de cap,
              depresie și anxietate. Somnul se va îmbunătăți.
            </li>
            <li class="about-list__item">
              <strong
                >Crește imunitatea și creează un mediu sănătos în organism. </strong
              >Veți fi în siguranță protejat de reinfectarea.
            </li>
          </ul>
          <div class="about-pack">
            <picture>
              <img
                class="about-pack--pack"
                loading="lazy"
                src="assets/images/product.png"
                alt="Detoxil water"
                width="358"
                height="409"
              />
            </picture>
            <div class="about-pack--choice animation__choice">
              <img
                loading="lazy"
                src="assets/images/choice.png"
                alt="choice"
                width="106"
                height="106"
              />
            </div>
            <img
              class="about-pack--cert"
              src="assets/images/cert.png"
              alt="certificate"
              width="139"
              height="190"
            />
          </div>
          <div class="about-box">
            <div class="about-form">
              <div class="form">
                <h2 class="form__title">
                  Numai astăzi<br /><span
                    class="form__title_color date-0"
                    data-format="dd monthFull"
                    >31 Августа</span
                  >
                </h2>
                <div>
                  Începutul promoției <span class="date-30">29.11.2020</span>
                </div>
                <div>
                  Promoția se termină <span class="date-0">30.11.2020</span>
                </div>
                  <br>
                <div class="form__price">
                  <div class="form__price-val">
                    <h5 class="form__price-title old-price">Prețul vechi</h5>
                    <p class="form__price-before">
                      <span
                        class="x_price_previous price_old form__price-before_line"
                        >318 RON</span
                      >
                    </p>
                  </div>
                  <div class="form_before"></div>
                  <div class="form__price-val">
                    <h5 class="form__price-title new-price">Prețul nou</h5>
                    <p class="form__price-after">
                      <span class="x_price_current price_main">159 RON</span>
                    </p>
                  </div>
                </div>


                <form     class="   orderForm   x_order_form cpa__order_form form__cont" method="post">
				<div class="form__input-wrap">    <label class="form__input-icon">
                      <img alt="name" height="23" loading="lazy" src="assets/images/name.png" width="19"/>
                    </label>
                    <input aria-label="name" class="form__input" name="name" placeholder="Numele meu" required="" type="text"/>
                  </div>
                  <div class="form__input-wrap">
                    <label class="form__input-icon">
                      <img alt="phone" height="23" loading="lazy" src="assets/images/phone.svg" width="19"/>
                    </label>
                    <input aria-label="phone" class="form__input" name="phone"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5"     placeholder="Telefonul meu" required="" type="tel"/>
                  </div>
                  <div class="form__wrapper-btn">
                    <button class="btn form__btn pulse" type="submit">Comandaţi<br/>
                      <span class="btn_size">cu reducere</span>
                    </button>
                  </div>
                  <div class="nw">
                    <img src="assets/images/delivery2.png" style="max-width: 45px; width: 100%"/>
                    <span>Privind costu livrării, va adresați la consultant</span>
                  </div>
                </form>


              </div>
              <div class="form-pay">
                <div class="form-pay__text online-people">
                  <img
                    class="online-img"
                    loading="lazy"
                    src="assets/images/eye.png"
                    alt="eye"
                    width="20"
                    height="13"
                  />
                  <p>
                    acum, pe site-ul
                    <span class="text-bold online-dynamic">30</span> de persoane
                  </p>
                </div>
                <div class="form-pay__text online-sold">
                  <img
                    class="online-img"
                    loading="lazy"
                    src="assets/images/eye.png"
                    alt="eye"
                    width="20"
                    height="13"
                  />
                  <p>
                    <span class="text-bold">116</span> vânzări în ultima oră
                  </p>
                </div>
              </div>
              <p class="form__privacy">
                Atenție! Au rămas
                <span class="color-red text-bold lastpack">80</span> de pachete.
              </p>
            </div>
          </div>
        </div>
        <p class="about-attention">
          <b
            >Remediul acționează asupra corpului ca un probiotic - normalizează
            activitatea intestinului, întărește imunitatea și elimină
            toxinele</b
          >
        </p>
        <div class="about-advantages">
          <div class="about-advantages-box">
            <div class="about-advantages__icon">
              <img
                loading="lazy"
                src="assets/images/advan1.png"
                alt="advantages"
                width="78"
                height="80"
              />
            </div>
            <h4 class="about-advantages__name">
              Fiabil<span class="about-advantages__name--small"
                >Fără erupții cutanate,<br />greață, amețeli</span
              >
            </h4>
          </div>
          <div class="about-advantages-box">
            <div class="about-advantages__icon">
              <img
                class="shield"
                loading="lazy"
                src="assets/images/advan2.png"
                alt="advantages"
                width="65"
                height="80"
              />
            </div>
            <h4 class="about-advantages__name">
              Sigur<span class="about-advantages__name--small"
                >Potrivit pentru copii <br />de la 6 ani</span
              >
            </h4>
          </div>
          <div class="about-advantages-box">
            <div class="about-advantages__icon">
              <img
                loading="lazy"
                src="assets/images/advan3.png"
                alt="advantages"
                width="80"
                height="80"
              />
            </div>
            <h4 class="about-advantages__name">
              Eficient<span class="about-advantages__name--small"
                >Pentru a purifica corpul</span
              >
            </h4>
          </div>
          <div class="about-advantages-box">
            <div class="about-advantages__icon">
              <img
                loading="lazy"
                src="assets/images/advan4.png"
                alt="advantages"
                width="80"
                height="76"
              />
            </div>
            <h4 class="about-advantages__name">
              Natural<span class="about-advantages__name--small"
                >Pe bază de plante</span
              >
            </h4>
          </div>
        </div>
      </div>
    </section>
    <section class="effect block bg-grey">
      <div class="container">
        <h2 class="effect__title title">
          Cum funcționează <span class="color">Detoxil water</span>?
        </h2>
        <div class="effect__wrap">
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-1.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-1.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Elimină toate tipurile de paraziți</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-2.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-2.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Elimină toxinele și produsele vieții lo</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-3.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-3.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">
              Neutralizează <br />
              procesele inflamatorii
            </p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-4.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-4.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Normalizează activitatea intestinului</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-5.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-5.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Restabilește activitatea tuturor organelor</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-6.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-6.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">Elimină reacțiile alergice</p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-7.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-7.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">
              Îmbunătățește funcțiile <br />
              de protecție ale organismului
            </p>
          </div>
          <div class="item">
            <div class="item__img">
              <picture>
                <source type="image/webp" "assets/images/effect-8.webp" />
                <img
                  loading="lazy"
                  src="assets/images/effect-8.jpg"
                  alt="photo"
                  width="270"
                  height="160"
                />
              </picture>
            </div>
            <p class="item__text">
              Accelerează procesul <br />
              de curățare a corpului
            </p>
          </div>
        </div>
      </div>
    </section>
    <div class="action block">
      <div class="container">
        <div class="action-form">
          <div class="action-form__prod">
            <picture>
              <img
                class="action-form__product"
                loading="lazy"
                src="assets/images/product.png"
                alt="product"
                width="358"
                height="409"
              />
            </picture>
            <div class="action-form__medal animation__choice">
              <img
                loading="lazy"
                src="assets/images/choice.png"
                alt="medal"
                width="106"
                height="106"
              />
            </div>
            <img
              class="action-form__cert"
              src="assets/images/cert-3.jpg"
              alt="medal"
            />
          </div>
          <div class="action-form__right">
            <p class="action-form__title text-bold">
              Atenție <span class="color-red">Promoție!</span>
            </p>
            <div class="action-form__top">
              <p class="action-form__date">
                Doar astăzi
                <span
                  class="color-red date-0"
                  data-format="dd monthFull"
                ></span>
              </p>
              <div class="action-form__percent">
                <img
                  loading="lazy"
                  src="assets/images/sale.png"
                  alt="sale-percent"
                  width="94"
                  height="71"
                />
              </div>
              <div class="action__timer timer">
                <div class="timer">
                  <div class="timer__text">
                    Până la sfârșitul promoţiei au rămas:
                  </div>
                  <div class="timer__block">
                    <div class="timer__hours">
                      <span class="hours">0</span><span class="hours">0</span>
                    </div>
                    <span class="timer__dots">:</span>
                    <div class="timer__minutes">
                      <span class="minutes">2</span
                      ><span class="minutes">7</span>
                    </div>
                    <span class="timer__dots">:</span>
                    <div class="timer__seconds">
                      <span class="seconds">0</span
                      ><span class="seconds">0</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="action-form--wrapper">
              <div class="action-form__prod--mob">
                <picture>
                  <img
                    class="action-form__product"
                    loading="lazy"
                    src="assets/images/product.png"
                    alt="product"
                    width="359"
                    height="409"
                  />
                </picture>
                <div class="action-form__medal--mob">
                  <img
                    loading="lazy"
                    src="assets/images/choice.png"
                    alt="medal"
                    width="106"
                    height="106"
                  />
                </div>
              </div>


              <form     class="   orderForm   x_order_form cpa__order_form" method="post">
              <div class="form__input-wrap">    <label class="form__input-icon">
                    <img alt="name" height="23" loading="lazy" src="assets/images/name.png" width="19"/>
                  </label>
                  <input aria-label="name" class="form__input" name="name" placeholder="Numele meu" required="" type="text"/>
                </div>
                <div class="form__input-wrap">
                  <label class="form__input-icon">
                    <img alt="phone" height="23" loading="lazy" src="assets/images/phone.svg" width="19"/>
                  </label>
                  <input aria-label="phone" class="form__input" name="phone"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5"     placeholder="Telefonul meu" required="" type="tel"/>
                </div>
                <button class="btn form__btn pulse" type="submit">Comandaţi<br/>
                  <span class="btn_size">cu reducere</span>
                </button>
              </form>


            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="components bg-grey block">
      <div class="container">
        <h2 class="components__title title">
          <span class="color">Detoxil water</span> îndepărtează în siguranță și
          eficient paraziții datorită compoziției naturale
        </h2>
        <div class="components__wrap">
          <div class="component">
            <div class="component__img">
              <picture>
                <source
                  media="(max-width:639px)"
                  "assets/images/component-1-mob.png"
                />
                <img
                  loading="lazy"
                  src="assets/images/component-1.png"
                  alt="component"
                  width="338"
                  height="166"
                />
              </picture>
            </div>
            <div class="component__info">
              <h4 class="component__ttl">Barberina</h4>
              <p class="component__text">
                Coaja de portocală are o reacție alcalină și inhibă activitatea viermilor.
              </p>
            </div>
          </div>
          <div class="component">
            <div class="component__img">
              <picture>
                <source
                  media="(max-width:639px)"
                  "assets/images/component-2-mob.png"
                />
                <img
                  loading="lazy"
                  src="assets/images/component-2.png"
                  alt="component"
                  width="359"
                  height="221"
                />
              </picture>
            </div>
            <div class="component__info">
              <h4 class="component__ttl">Guarana</h4>
              <p class="component__text">
                Extractele din semințe de guarana au efecte antimicrobiene și antioxidante.
              </p>
            </div>
          </div>
          <div class="component">
            <div class="component__img">
              <picture>
                <source
                  media="(max-width:639px)"
                  "assets/images/component-3-mob.png"
                />
                <img
                  loading="lazy"
                  src="assets/images/component-3.png"
                  alt="component"
                  width="287"
                  height="220"
                />
              </picture>
            </div>
            <div class="component__info">
              <h4 class="component__ttl">Ananas</h4>
              <p class="component__text">
                Bromelaina din ananas are capacitatea de a dizolva cochiliile viermilor.
              </p>
            </div>
          </div>
          
        </div>

        <div class="components__wrap">
            <div class="component">
              <div class="component__img">
                <picture>
                  <source
                    media="(max-width:639px)"
                    "assets/images/component-5-mob.png"
                  />
                  <img
                    loading="lazy"
                    src="assets/images/component-4.png"
                    alt="component"
                    width="338"
                    height="166"
                  />
                </picture>
              </div>
              <div class="component__info">
                <h4 class="component__ttl">Cafea verde</h4>
                <p class="component__text">
                    Are proprietăți antihelmintice, ameliorează durerile și normalizează digestia.
                </p>
              </div>
            </div>
            <div class="component">
              <div class="component__img">
                <picture>
                  <source
                    media="(max-width:639px)"
                    "assets/images/component-5-mob.png"
                  />
                  <img
                    loading="lazy"
                    src="assets/images/component-5.png"
                    alt="component"
                    width="359"
                    height="221"
                  />
                </picture>
              </div>
              <div class="component__info">
                <h4 class="component__ttl">Matjes</h4>
                <p class="component__text">
                    Tonifică vasele de sânge și neutralizează procesele inflamatorii din organism.
                </p>
              </div>
            </div>
            <div class="component">
              <div class="component__img">
                <picture>
                  <source
                    media="(max-width:639px)"
                    "assets/images/component-6-mob.png"
                  />
                  <img
                    loading="lazy"
                    src="assets/images/component-6.png"
                    alt="component"
                    width="287"
                    height="220"
                  />
                </picture>
              </div>
              <div class="component__info">
                <h4 class="component__ttl">Sparanghel</h4>
                <p class="component__text">
                    Ajută la eliminarea viermilor, a larvelor și a ouălor. Ajută la îmbunătățirea digestiei
                </p>
              </div>
            </div>
            
          </div>
      </div>
    </div>
    <section class="efficiency block">
      <div class="container">
        <h2 class="efficiency__title title">
          Eficacitatea <span class="color-red">Detoxil water </span>au confirmat
          rezultatele studiilor clinice
        </h2>
        <p class="efficiency__subtitle">
          La testele centrului European de sănătate au participat 1403 de
          voluntari
        </p>
        <div class="efficiency-contant">
          <div class="efficiency-pack">
            <picture>
              <img
                class="efficiency-pack--pack"
                loading="lazy"
                src="assets/images/product.png"
                alt="Detoxil water"
                width="358"
                height="409"
              />
            </picture>
            <div class="efficiency-pack--choice">
              <img
                loading="lazy"
                src="assets/images/choice.png"
                alt="choice"
                width="106"
                height="106"
              />
            </div>
            <img
              class="efficiency-pack--cert"
              src="assets/images/cert.png"
              alt="certificate"
              width="139"
              height="190"
            />
          </div>
          <ul class="efficiency-list">
            <li class="efficiency-box">
              <h3 class="efficiency-box__num">
                97<span class="efficiency-box__num--percent">%</span>
              </h3>
              <p class="efficiency-box__text">au scăpat de paraziți</p>
            </li>
            <li class="efficiency-box">
              <h3 class="efficiency-box__num efficiency-box__num--border">
                93<span class="efficiency-box__num--percent">%</span>
              </h3>
              <p class="efficiency-box__text">
                au simțit un val<br />de putere și energie
              </p>
            </li>
            <li class="efficiency-box">
              <h3 class="efficiency-box__num">
                90<span class="efficiency-box__num--percent">%</span>
              </h3>
              <p class="efficiency-box__text">
                au încetat să se<br />îmbolnăvească și au<br />început să arate
                mai bine
              </p>
            </li>
          </ul>
        </div>
        <p class="efficiency__info">
          Un studiu de control a arătat absența completă a efectelor secundare
          după cursul Detoxil water
        </p>
        <button class="btn efficiency__btn ever-popup-btn">
          Comandaţi<br /><span class="btn_size"> cu reducere</span>
        </button>
      </div>
    </section>
    <section class="block expert bg-grey">
      <div class="container">
        <h2 class="title expert__title">
          Expertul recomandă <span class="color-red">Detoxil water</span>
        </h2>
        <div class="expert__main">
          <picture>
            <source media="(max-width:767px)" "assets/images/dot.png" />
            <source type="image/webp" "assets/images/expert.webp" />
            <source "assets/images/expert.png" />
            <img
              class="expert__left--bg"
              src="assets/images/expert.png"
              alt="expert"
              width="979"
              height="768"
            />
          </picture>
          <div class="expert__right">
            <p class="expert__subtitle">Primul remediu cu acțiune probiotică</p>
            <div class="shadow">
              <div class="expert__right--text">
                <p>
                  <b
                    >În 80% din cazuri, helminții sunt vinovați de deteriorarea
                    sănătății și a bunăstării!</b
                  >Și cu cât sunt mai mulţi în organism, cu atât mai mult
                  dăunează.
                </p>
                <p>
                  De aceea este atât de important să se ia măsuri în timp util
                  și eficient.<b
                    >Dar este necesar să scăpați corect de viermi.</b
                  >
                </p>
                <p>
                  medicamente nu elimină ouăle, astfel helminții continuă să se
                  înmulțească și să trăiască cu succes. Alții - nu elimină
                  toxinele, ceea ce înseamnă că organismul continuă să se
                  descompună. Al treilea - ucide microflora intestinală și sunt
                  însoțite de efecte secundare.
                </p>
                <p>
                  <b
                    >Anterior, a trebuit să cumpărați 3 remedii - eliminarea
                    helminților, curățarea și restaurarea corpului. Acum, toate
                    aceste caracteristici oferă Detoxil water.</b
                  >
                </p>
                <p>
                  Acest remediu fiabil acționează ca un probiotic, deci este
                  complet sigur pentru organism. Detoxil water<b
                    >ucide și elimină toate tipurile de paraziți și ouăle lor,
                    curăță corpul de toxine, otrăvuri și toxine. Ajută la
                    restabilirea imunității și la prevenirea recidivei</b
                  >
                </p>
                <p>
                  Acest instrument poate și trebuie luat de întreaga familie.<br />Copii
                  de la 6 ani.
                </p>
              </div>
            </div>
            <div class="expert__right--line"></div>
            <div class="expert__right--doc">
              <div class="expert__right--doc-full">
                <div class="expert__right--doc-name">Adela Golescu</div>
                <div class="expert__right--doc-prof">
                  <em>principalul infectionist<br />al clinicii private</em>
                </div>
              </div>
              <img
                class="sign"
                loading="lazy"
                src="assets/images/sign.png"
                alt="sign"
              /><img
                class="approved"
                loading="lazy"
                src="assets/images/approved.png"
                alt="approved"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="cert block">
      <div class="container">
        <h2 class="title cert__title">
          Certificatele <span class="color-red">Detoxil water</span>
        </h2>
        <div class="cert__main">
          <picture>
            <source type="image/webp" "assets/images/cert1.png" />
            <img
              alt="certificate"
              src="assets/images/cert1.png"
              loading="lazy"
              width="210"
              height="84"
            /> </picture
          ><span class="line"></span>
          <picture>
            <source type="image/webp" "assets/images/cert2.png" />
            <img
              alt="certificate"
              src="assets/images/cert2.png"
              loading="lazy"
              width="210"
              height="84"
            /> </picture
          ><span class="line"></span>
          <picture>
            <source type="image/webp" "assets/images/cert-3.jpg" />
            <img
              alt="certificate"
              src="assets/images/cert-3.jpg"
              loading="lazy"
              width="210"
              height="84"
            />
          </picture>
        </div>
      </div>
    </section>
    <div class="bg-grey">
      <div class="action block">
        <div class="container">
          <div class="action-form">
            <div class="action-form__prod">
              <picture>
                <img
                  class="action-form__product"
                  loading="lazy"
                  src="assets/images/product.png"
                  alt="product"
                  width="358"
                  height="409"
                />
              </picture>
              <div class="action-form__medal animation__choice">
                <img
                  loading="lazy"
                  src="assets/images/choice.png"
                  alt="medal"
                  width="106"
                  height="106"
                />
              </div>
              <img
                class="action-form__cert"
                src="assets/images/cert-3.jpg"
                alt="medal"
              />
            </div>
            <div class="action-form__right">
              <p class="action-form__title text-bold">
                Atenție <span class="color-red">Promoție!</span>
              </p>
              <div class="action-form__top">
                <p class="action-form__date">
                  Doar astăzi
                  <span
                    class="color-red date-0"
                    data-format="dd monthFull"
                  ></span>
                </p>
                <div class="action-form__percent">
                  <img
                    loading="lazy"
                    src="assets/images/sale.png"
                    alt="sale-percent"
                    width="94"
                    height="71"
                  />
                </div>
                <div class="action__timer timer">
                  <div class="timer">
                    <div class="timer__text">
                      Până la sfârșitul promoţiei au rămas:
                    </div>
                    <div class="timer__block">
                      <div class="timer__hours">
                        <span class="hours">0</span><span class="hours">0</span>
                      </div>
                      <span class="timer__dots">:</span>
                      <div class="timer__minutes">
                        <span class="minutes">2</span
                        ><span class="minutes">7</span>
                      </div>
                      <span class="timer__dots">:</span>
                      <div class="timer__seconds">
                        <span class="seconds">0</span
                        ><span class="seconds">0</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="action-form--wrapper">
                <div class="action-form__prod--mob">
                  <picture>
                    <img
                      class="action-form__product"
                      loading="lazy"
                      src="assets/images/product.png"
                      alt="product"
                      width="359"
                      height="409"
                    />
                  </picture>
                  <div class="action-form__medal--mob">
                    <img
                      loading="lazy"
                      src="assets/images/choice.png"
                      alt="medal"
                      width="106"
                      height="106"
                    />
                  </div>
                </div>


                <form     class="   orderForm   x_order_form cpa__order_form" method="post">
				<div class="form__input-wrap">   <label class="form__input-icon">
                      <img alt="name" height="23" loading="lazy" src="assets/images/name.png" width="19"/>
                    </label>
                    <input aria-label="name" class="form__input" name="name" placeholder="Numele meu" required="" type="text"/>
                  </div>
                  <div class="form__input-wrap">
                    <label class="form__input-icon">
                      <img alt="phone" height="23" loading="lazy" src="assets/images/phone.svg" width="19"/>
                    </label>
                    <input aria-label="phone" class="form__input" name="phone"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5"     placeholder="Telefonul meu" required="" type="tel"/>
                  </div>
                  <button class="btn form__btn pulse" type="submit">Comandaţi<br/>
                    <span class="btn_size">cu reducere</span>
                  </button>
                </form>


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <section class="reviews block" id="rew">
      <div class="container reviews__wrap">
        <h2 class="reviews__title title">
          Recenzii ale clienților despre
          <span class="color">Detoxil water</span>
        </h2>
        <div class="reviews__slider js-reviews-slider">
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-1.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-1.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Constantin, 37 de ani,</p>
              <p class="slide__city">Iaşi</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">Nu am observat efecte secundare</p>
              <p class="slide__text">
                Nu-mi place să beau pastile și tot felul de medicamente. Dar
                când a început să doară constant stomacul și capul, am suspectat
                viermii. Am ales Detoxil water, deoarece ucide viermii și nu
                dăunează corpului, ci, dimpotrivă, îl restabilește. Durerile de
                cap au trecut, funcţia stomacului s-a îmbunătățit. Chiar și
                pielea arată mai sănătoasă. Nu au existat efecte secundare, sunt
                mulțumit de tot.
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-2.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-2.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Elena, 41 de ani,</p>
              <p class="slide__city">Bucureşti</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">Fiul a încetat să mai fie bolnav.</p>
              <p class="slide__text">
                Fiul a fost foarte bolnăvicios: doar îl duc la grădiniță -
                imediat bolnav. Am făcut o analiză pentru viermi, dar nu a
                arătat nimic. Se pare că trebuie făcut de trei ori pentru a fi
                sigur. La fiu a fost găsit pentru a doua oară paraziți, la soțul
                meu și cu mine - pentru a treia oară ... la sfatul medicului
                timp de aproximativ o lună, am luat picături Detoxil water.
                Fiul a mers la grădiniță timp de 2 luni și nu se îmbolnăvește,
                iar soțul meu și cu mine avem mai multă energie.
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-3.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-3.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Erica, 32 de ani,</p>
              <p class="slide__city">Timişoara</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">
                Pielea a devenit mai frumoasă și mai sănătoasă
              </p>
              <p class="slide__text">
                Există suspiciuni că am fost infectată cu paraziți de la câinele
                meu Jack. A apărut o erupție severă pe mâini, care mă mânca
                puternic. Am crezut că e lichen, dar la spital au spus că nu.
                Unguentul nu a ajutat. Apoi am auzit într-un program că ar putea
                fi viermi. Despre Detoxil water am aflat pe forum și am decis să
                comand. După curs, a trecut erupția cutanată și chiar coşurile
                de pe față! Acum cred că şi pentru Jack îi voi comanda aceste
                picături).
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-4.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-4.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Marcel, 52 de ani,</p>
              <p class="slide__city">Brăila</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">Nu mai mânca prea mult.</p>
              <p class="slide__text">
                Un remediu bun, mi-a plăcut. Datorită lui, el a încetat să
                mănânce seara, sau chiar mai devreme a venit de la locul de
                muncă și nu m-am putut opri. S-a dovedit că am avut un astfel de
                apetit crescut din cauza paraziților. Înainte de aceasta, am
                încercat alte mijloace, dar nimic nu sa schimbat. Detoxil water
                a scos viermii și a oprit supraalimentarea.
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-5.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-5.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Maria, 27 de ani,</p>
              <p class="slide__city">Oradea</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">
                Am pierdut greutatea și am intrat din nou în blugi
              </p>
              <p class="slide__text">
                Am încercat mult timp să pierd în greutate, dar dieta și sportul
                nu erau de ajuns, iar mijloacele de a pierde în greutate nu m-au
                ajutat. Un specialist mi-a spus că nu pot pierde în greutate din
                cauza viermilor și mi-a sfătuit Detoxil water. Am comandat, am
                plătit la primire și am început să-l beau. La început, rezultat nu a fost, dar după 4
                săptămâni, cântarii au arătat minus 5!
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-6.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-6.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Zarema, 48 de ani,</p>
              <p class="slide__city">Suceava</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">Fiul a început să învețe mai bine</p>
              <p class="slide__text">
                Am bănuit că nu era în regulă când fiul a luat o sesiune
                proastă. Apoi sa dovedit că are și dureri abdominale în partea
                dreaptă. M-am gândit că sunt helminți. Un terapeut cunoscut mi-a
                sfătuit Detoxil water. Au mituit cuvintele ei că el scoate totul
                și mărește imunitatea. După un curs, fiul a început mult mai
                bine să învețe. Eu însăşi le-am luat și mi-am pierdut anxietatea
                constantă, vertijul. Deci, pot să le recomand.
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-7.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-7.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Laura, 54 de ani,</p>
              <p class="slide__city">Baia Mare</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">Un remediu bun pentru prevenire</p>
              <p class="slide__text">
                Pisica noastră trăiește acasă, așa că apare problema prevenției
                în mod regulat. Ultima dată când ne-am îmbolnăvit, am decis să
                renunțăm la remediul vechi și să găsim unu nou. Am încercat
                Detoxil water și ne-am simțit bine. Nu știu dacă a ieșit ceva,
                pentru că nu m-am uitat prea mult, dar sper că a ajutat.
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-8.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-8.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Mia, 32 de ani,</p>
              <p class="slide__city">Botoşani</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">Detoxil water - must have al meu!</p>
              <p class="slide__text">
                Întotdeauna beau după vară și nu-mi amintesc când a fost ultima
                dată când am avut gripă sau răceală. Îmi place că acestea sunt
                picături, convenabil de a lua. Nu există stomac deranjat de la
                ele, deși de la multe mijloace mă simt rău. Cu siguranță voi
                comanda pentru sine și vă recomand tuturor!
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
          <div class="slide">
            <div class="slide__photo">
              <picture>
                <source "assets/images/slide-9.webp" type="image/webp" />
                <img
                  class="slide__img"
                  loading="lazy"
                  src="assets/images/slide-9.png"
                  alt="photo"
                  width="130"
                  height="130"
                />
              </picture>
            </div>
            <div class="slide__info">
              <p class="slide__name">Marta, 34 de ani,</p>
              <p class="slide__city">Bucureşti</p>
            </div>
            <div class="slide__desc js-comment" data-expanded="false">
              <p class="slide__main">
                Cât de mult aș economisi bani dacă aș găsi Detoxil water
                înainte!
              </p>
              <p class="slide__text">
                Am cumpărat fonduri scumpe împotriva căderii părului, și sa
                dovedit că motivul este paraziții! Datorită acestor picături, a
                încetat să cadă părul și ci chiar sa îngroșat vizibil! Și
                unghiile mai lungi și puternice au început să crească. Sunt
                foarte mulțumită de rezultat!
              </p>
            </div>
            <div class="slide__btn js-show-comment"></div>
          </div>
        </div>
        <p class="reviews__text">
          Aţi luat Detoxil water? Ajutați-i pe alții să se asigure de
          eficacitatea sa.
        </p>
        <button class="btn toggle-form-btn reviews__btn">
          Lăsaţi feedback
        </button>
        <div class="reviews__cta reviews-cta">
          <form  method="post" class="reviews__form reviews-form">

		  <div class="reviews-form__row">        <div
                class="reviews-form__field-wrap reviews-form__field-wrap--name reviews-form__input-text"
              >
                <input
                  class="reviews-form__input reviews-form__input-name reviews-form__field reviews-input reviews-input-text"
                  type="text"
                  placeholder="Numele meu"
                /><span class="reviews-form__error"
                  >Utilizați caractere de la a la z</span
                >
              </div>
              <div
                class="reviews-form__field-wrap reviews-form__field-wrap--city reviews-form__input-text"
              >
                <input
                  class="reviews-form__input reviews-form__input-name reviews-form__field reviews-input reviews-input-text"
                  type="text"
                  placeholder="Orașul meu"
                /><span class="reviews-form__error"
                  >Utilizați caractere de la a la z</span
                >
              </div>
              <div
                class="reviews-form__field-wrap reviews-form__field-wrap--age reviews-form__wrap-num"
              >
                <input
                  class="reviews-form__input reviews-form__field input-num input-age reviews-input"
                  type="number"
                  placeholder="Vârsta mea"
                  min="0"
                /><span class="reviews-form__error"
                  >Introduceți o valoare cuprinsă între 18 și 90</span
                >
              </div>
              <div class="reviews-form__intrenal-col">
                <label class="reviews-form__file" for="file"
                  ><span class="reviews-form__file-img"
                    ><span class="reviews-form__checkmark-icon"
                      ><svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                      >
                        <path
                          fill="#0f0"
                          d="M20.285 2l-11.285 11.567-5.286-5.011-3.714 3.716 9 8.728 15-15.285z"
                        ></path></svg></span></span
                  ><span class="reviews-form__file-text"
                    >Încărcați fotografia</span
                  ></label
                ><input
                  class="visually-hidden input-file reviews-input"
                  id="file"
                  type="file"
                  accept="image/*"
                />
              </div>
              <div
                class="reviews-form__field-wrap reviews-form__field-wrap--message reviews-form__input-text"
              >
                <textarea
                  class="reviews-form__textarea reviews-form__field reviews-input"
                  name="review"
                  placeholder="Mesaj"
                ></textarea
                ><span class="reviews-form__error">Lăsați un comentariu</span>
              </div>
            </div>
            <button class="btn btn--smaller reviews__btn reviews-form__btn">
              Trimiteţi
            </button>
            <select
              id="country"
              name="country"
              class="country_select"
              style="display: none"
            ></select>
          </form>
        </div>
        <div class="reviews-popup">
          <div class="reviews-popup__inner">
            <div class="reviews-popup__text">
              <span class="reviews-popup__big">Mulțumesc!</span
              ><br />Feedback-ul dvs. este acceptat și trimis la moderare!
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="how block">
      <div class="container">
        <h2 class="title how__title">
          Trei pași simpli pentru a trăi fără paraziți
        </h2>
        <div class="how__main">
          <div class="how__left how-pack">
            <picture>
              <img
                class="how-pack--pack"
                loading="lazy"
                src="assets/images/product.png"
                alt="Detoxil water"
                width="358"
                height="409"
              />
            </picture>
            <div class="how-pack--choice animation__choice">
              <img
                loading="lazy"
                src="assets/images/choice.png"
                alt="choice"
                width="106"
                height="106"
              />
            </div>
            <img
              class="how-pack--cert"
              src="assets/images/cert.png"
              alt="certificate"
              width="139"
              height="190"
            />
            <picture>
              <source media="(max-width:767px)" "assets/images/dot.png" />
              <source type="image/webp" "assets/images/flowers.webp" />
              <img
                class="how-pack--flow"
                loading="lazy"
                src="assets/images/flowers.png"
                alt="flowers"
                width="290"
                height="230"
              />
            </picture>
          </div>
          <ul class="how__right">
            <li class="how__right-el">
              <div class="how__right-el--img--1 how__right-el--img">
                <img
                  loading="lazy"
                  src="assets/images/how1.png"
                  alt="usage"
                  width="119"
                  height="119"
                />
              </div>
              <p>50 picături de Detoxil Water</p>
            </li>
            <li class="how__right-el">
              <div class="how__right-el--img--2 how__right-el--img">
                <img
                  loading="lazy"
                  src="assets/images/how2.png"
                  alt="usage"
                  width="119"
                  height="119"
                />
              </div>
              <p>Luați de 2 ori pe zi</p>
            </li>
            <li class="how__right-el">
              <div class="how__right-el--img--3 how__right-el--img">
                <img
                  loading="lazy"
                  src="assets/images/how3.png"
                  alt="usage"
                  width="119"
                  height="119"
                />
              </div>
              <p>Curs de 30 de zile</p>
            </li>
          </ul>
        </div>
      </div>
    </section>
    <div class="steps bg-grey">
      <div class="steps__second">
        <div class="container">
          <img
            class="steps__expert"
            loading="lazy"
            src="assets/images/doctor-small.png"
            alt="expert"
            width="208"
            height="343"
          />
          <div class="steps__second--recommend">
            <p>
              <b>Recomandările Adelei Golescu,</b
              ><span>principalul infectionist al clinicii private</span>
            </p>
            <img
              src="assets/images/approved.png"
              alt="approver"
              width="124"
              height="60"
            />
          </div>
          <ul class="steps__second--list">
            <li class="steps__second--list-el">
              <div class="step__checkmark">
                <img
                  loading="lazy"
                  src="assets/images/step_check.png"
                  alt="check"
                  width="21"
                  height="18"
                />
              </div>
              <p>
                <span>Pentru a accelera efectul, Detoxil water </span>trebuie să
                aderaţi la o nutriție adecvată
              </p>
            </li>
            <li class="steps__second--list-el">
              <div class="step__checkmark">
                <img
                  loading="lazy"
                  src="assets/images/step_check.png"
                  alt="check"
                  width="21"
                  height="18"
                />
              </div>
              <p>
                <span>Pentru efectul maxim al Detoxil water </span>după
                administrare, trebuie să luați mai multe legume și fructe, care
                sunt bogate în vitamine
              </p>
            </li>
            <li class="steps__second--list-el">
              <div class="step__checkmark">
                <img
                  loading="lazy"
                  src="assets/images/step_check.png"
                  alt="check"
                  width="21"
                  height="18"
                />
              </div>
              <p>
                <span>Pentru a preveni infecția cu paraziți, </span>trebuie să
                respectați regulile de igienă și să efectuați prevenirea
              </p>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <section class="order block" id="order">
      <div class="container">
        <h2 class="order__title title">
          Cum să comandați <span class="color">Detoxil water</span>
        </h2>
        <div class="order__list">
          <div class="order-item">
            <div class="order-item__img">
              <picture>
                <source "assets/images/order-1.webp" type="image/webp" />
                <img
                  loading="lazy"
                  src="assets/images/order-1.jpg"
                  alt="photo"
                  width="160"
                  height="160"
                />
              </picture>
            </div>
            <div class="order-item__desc">
              <p class="order-item__ttl">
                Completați<br />formularul de comandă
              </p>
              <p class="order-item__text">
                Introduceți doar numele<br />și numărul dvs. de telefon
              </p>
            </div>
          </div>
          <div class="order-item">
            <div class="order-item__img">
              <picture>
                <source "assets/images/order-2.webp" type="image/webp" />
                <img
                  loading="lazy"
                  src="assets/images/order-2.jpg"
                  alt="photo"
                  width="160"
                  height="160"
                />
              </picture>
            </div>
            <div class="order-item__desc">
              <p class="order-item__ttl">
                Răspundeți <br />la apelul operatorului
              </p>
              <p class="order-item__text">
                Acesta va clarifica datele dvs.<br />de adresă și va răspunde la
                toate întrebările
              </p>
            </div>
          </div>
          <div class="order-item">
            <div class="order-item__img">
              <picture>
                <source "assets/images/order-3.webp" type="image/webp" />
                <img
                  loading="lazy"
                  src="assets/images/order-3.jpg"
                  alt="photo"
                  width="160"
                  height="160"
                />
              </picture>
            </div>
            <div class="order-item__desc">
              <p class="order-item__ttl">Plătiți <br />după primire</p>
              <p class="order-item__text">
                Nu este necesară plata<br />în avans
              </p>
            </div>
          </div>
          <div class="order-item">
            <div class="order-item__img">
              <picture>
                <source "assets/images/order-4.webp" type="image/webp" />
                <img
                  loading="lazy"
                  src="assets/images/order-4.jpg"
                  alt="photo"
                  width="160"
                  height="160"
                />
              </picture>
            </div>
            <div class="order-item__desc">
              <p class="order-item__ttl">Bucurați-vă<br />de efect</p>
              <p class="order-item__text">
                Spuneți la revedere paraziților <br />și simțiți un val de
                putere
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="first-block promo block">
      <div class="container">
        <h1 class="promo__title--mob">Detoxil water</h1>
        <h3 class="promo__subtitle--mob">
          Distruge toate tipurile de helminți și elimină toxinele din organism
        </h3>
        <div class="promo__cont">
          <div class="promo__man">
            <picture>
              <source media="(max-width:1023px)" "assets/images/dot.png" />
              <source type="image/webp" "assets/images/promo-people.webp" />
              <img
                src="assets/images/promo-people.png"
                alt="family"
                width="818"
                height="602"
              />
            </picture>
          </div>
          <div class="promo__description">
            <h1 class="promo__title">Detoxil water</h1>
            <h3 class="promo__subtitle">
              Distruge toate tipurile de helminți și elimină toxinele din
              organism
            </h3>
            <ul class="promo__list">
              <li class="promo__list-item">
                <span class="promo__list-item_weight"
                  ><b>Potrivit </b>pentru curățarea complexă a helminților și
                  prevenirea</span
                >
              </li>
              <li class="promo__list-item">
                <span class="promo__list-item_weight"
                  ><b>Sigur </b>și 100% remediu natural</span
                >
              </li>
              <li class="promo__list-item">
                <span class="promo__list-item_weight"
                  ><b>Eficacitatea </b>este dovedită clinic</span
                >
              </li>
            </ul>
            <p class="promo__pack">Fără efecte secundare</p>
            <div class="promo__medals">
              <img
                loading="lazy"
                src="assets/images/promo-sign1.png"
                alt="medal"
                width="105"
                height="83"
              /><img
                loading="lazy"
                src="assets/images/promo-sign2.png"
                alt="medal"
                width="85"
                height="85"
              /><img
                loading="lazy"
                src="assets/images/promo-sign3.png"
                alt="medal"
                width="92"
                height="84"
              />
            </div>
            <div class="product">
              <picture>
                <img
                  src="assets/images/product.png"
                  alt="product"
                  width="358"
                  height="409"
                />
              </picture>
              <div class="product__before animation__choice">
                <img
                  src="assets/images/choice.png"
                  alt="medal"
                  width="106"
                  height="106"
                />
              </div>
            </div>
          </div>
          <div class="promo__form">
            <div class="form">
              <h2 class="form__title">
                Numai astăzi<br /><span
                  class="form__title_color date-0"
                  data-format="dd monthFull"
                  >31 Августа</span
                >
              </h2>
              <div>
                Începutul promoției <span class="date-30">29.11.2020</span>
              </div>
              <div>
                Promoția se termină <span class="date-0">30.11.2020</span>
              </div>
                <br>
              <div class="form__price">
                <div class="form__price-val">
                  <h5 class="form__price-title old-price">Prețul vechi</h5>
                  <p class="form__price-before">
                    <span
                      class="x_price_previous price_old form__price-before_line"
                      >318 RON</span
                    >
                  </p>
                </div>
                <div class="form_before"></div>
                <div class="form__price-val">
                  <h5 class="form__price-title new-price">Prețul nou</h5>
                  <p class="form__price-after">
                    <span class="x_price_current price_main">159 RON</span>
                  </p>
                </div>
              </div>


              <form     class="   orderForm   x_order_form cpa__order_form form__cont" method="post">
			  <div class="form__input-wrap">             <label class="form__input-icon">
                    <img alt="name" height="23" loading="lazy" src="assets/images/name.png" width="19"/>
                  </label>
                  <input aria-label="name" class="form__input" name="name" placeholder="Numele meu" required="" type="text"/>
                </div>
                <div class="form__input-wrap">
                  <label class="form__input-icon">
                    <img alt="phone" height="23" loading="lazy" src="assets/images/phone.svg" width="19"/>
                  </label>
                  <input aria-label="phone" class="form__input" name="phone"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5"     placeholder="Telefonul meu" required="" type="tel"/>
                </div>
                <div class="form__wrapper-btn">
                  <button class="btn form__btn pulse" type="submit">Comandaţi<br/>
                    <span class="btn_size">cu reducere</span>
                  </button>
                </div>
                <div class="nw">
                  <img src="assets/images/delivery2.png" style="max-width: 45px; width: 100%"/>
                  <span>Privind costu livrării, va adresați la consultant</span>
                </div>
              </form>


            </div>
            <div class="form-pay">
              <div class="form-pay__text online-people">
                <img
                  class="online-img"
                  loading="lazy"
                  src="assets/images/eye.png"
                  alt="eye"
                  width="20"
                  height="13"
                />
                <p>
                  acum, pe site-ul
                  <span class="text-bold online-dynamic">30</span> de persoane
                </p>
              </div>
              <div class="form-pay__text online-sold">
                <img
                  class="online-img"
                  loading="lazy"
                  src="assets/images/eye.png"
                  alt="eye"
                  width="20"
                  height="13"
                />
                <p><span class="text-bold">116</span> vânzări în ultima oră</p>
              </div>
            </div>
            <p class="form__privacy">
              Atenție! Au rămas
              <span class="color-red text-bold lastpack">80</span> de pachete.
            </p>
          </div>
        </div>
      </div>
    </section>
    <footer class="footer">
      <div class="container">
        <div
          class="create_rom_footer"
          data-color_text="#000"
          data-color_link="#000"
          data-color_logo="#fff"
        ></div>
      </div>
    </footer>
    <div class="ever-popup-build">
      <div class="popup" id="cloneThis">
        <div class="popup__wrapper">
          <h2 class="popup__title">
            Comandaţi <span class="color-red">Detoxil water</span>
          </h2>
          <picture>
            <img class="popup__img" src="assets/images/product.png" alt="product" />
          </picture>
          <div class="popup__prod--choice animation__choice">
            <img src="assets/images/choice.png" alt="medal" />
          </div>
          <picture>
            <source media="(max-width:767px)" "assets/images/dot.png" />
            <source type="image/webp" "assets/images/flowers.webp" />
            <img
              class="popup__prod--flow"
              src="assets/images/flowers.png"
              alt="flowers"
            />
          </picture>
        </div>
        <div class="popup__form">
          <div class="form">
            <h2 class="form__title">
              Numai astăzi<br /><span
                class="form__title_color date-0"
                data-format="dd monthFull"
                >31 Августа</span
              >
            </h2>
            <div>
              Începutul promoției <span class="date-30">29.11.2020</span>
            </div>
            <div>
              Promoția se termină <span class="date-0">30.11.2020</span>
            </div>
              <br>
            <div class="form__price">
              <div class="form__price-val">
                <h5 class="form__price-title old-price">Prețul vechi</h5>
                <p class="form__price-before">
                  <span
                    class="x_price_previous price_old form__price-before_line"
                    >318 RON</span
                  >
                </p>
              </div>
              <div class="form_before"></div>
              <div class="form__price-val">
                <h5 class="form__price-title new-price">Prețul nou</h5>
                <p class="form__price-after">
                  <span class="x_price_current price_main">159 RON</span>
                </p>
              </div>
            </div>


            <form     class="   orderForm   x_order_form cpa__order_form form__cont" method="post">
			<div class="form__input-wrap">    <label class="form__input-icon">
                  <img alt="name" height="23" loading="lazy" src="assets/images/name.png" width="19"/>
                </label>
                <input aria-label="name" class="form__input" name="name" placeholder="Numele meu" required="" type="text"/>
              </div>
              <div class="form__input-wrap">
                <label class="form__input-icon">
                  <img alt="phone" height="23" loading="lazy" src="assets/images/phone.svg" width="19"/>
                </label>
                <input aria-label="phone" class="form__input" name="phone"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5"     placeholder="Telefonul meu" required="" type="tel"/>
              </div>
              <div class="form__wrapper-btn">
                <button class="btn form__btn pulse" type="submit">Comandaţi<br/>
                  <span class="btn_size">cu reducere</span>
                </button>
              </div>
              <div class="nw">
                <img src="assets/images/delivery2.png" style="max-width: 45px; width: 100%"/>
                <span>Privind costu livrării, va adresați la consultant</span>
              </div>
            </form>


          </div>
          <div class="form-pay">
            <div class="form-pay__text online-people">
              <img
                class="online-img"
                loading="lazy"
                src="assets/images/eye.png"
                alt="eye"
                width="20"
                height="13"
              />
              <p>
                acum, pe site-ul
                <span class="text-bold online-dynamic">30</span> de persoane
              </p>
            </div>
            <div class="form-pay__text online-sold">
              <img
                class="online-img"
                loading="lazy"
                src="assets/images/eye.png"
                alt="eye"
                width="20"
                height="13"
              />
              <p><span class="text-bold">116</span> vânzări în ultima oră</p>
            </div>
          </div>
          <p class="form__privacy">
            Atenție! Au rămas
            <span class="color-red text-bold lastpack">80</span> de pachete.
          </p>
        </div>
      </div>
    </div>
    <div class="banner">
      <div class="container">
        <div class="banner__image">
          <picture>
            <source media="(max-width:639px)" "assets/images/dot.png" />
            <img
              src="assets/images/product.png"
              alt="image"
              loading="lazy"
              width="80"
              height="91"
            />
          </picture>
        </div>
        <div class="banner__title">
          Numai astăzi <span class="date-0" data-format="dd monthFull"></span>
        </div>
        <div class="banner__plashka">
          <picture>
            <source media="(max-width:1023px)" "assets/images/dot.png" />
            <img
              class="banner__sale"
              src="assets/images/banner-sale.png"
              alt="image"
              loading="lazy"
              width="80"
              height="61"
            />
          </picture>
        </div>
        <div class="timer">
          <div class="timer__text">Până la sfârșitul promoţiei au rămas:</div>
          <div class="timer__block">
            <div class="timer__hours">
              <span class="hours">0</span><span class="hours">0</span>
            </div>
            <span class="timer__dots">:</span>
            <div class="timer__minutes">
              <span class="minutes">2</span><span class="minutes">7</span>
            </div>
            <span class="timer__dots">:</span>
            <div class="timer__seconds">
              <span class="seconds">0</span><span class="seconds">0</span>
            </div>
          </div>
        </div>
        <div class="banner__btn btn ever-popup-btn">Comandaţi</div>
      </div>
    </div>

    <script defer="" src="assets/js/slick.min.js"></script>
    <script defer="" src="assets/js/main.js"></script>


    <script>
      var cookies = (function (a) {
        if (a == "") return {};
        var b = {};
        for (var i = 0; i < a.length; ++i) {
          var p = a[i].split("=");
          if (p.length != 2) continue;
          b[p[0]] = p[1];
        }

        return b;
      })(document.cookie.split("; "));

      //для клонирования блока в попап используются следующие айдишники
      // #cloneThis - для десктопа
      // #cloneMobileThis - для мобильного (если нужно)
      //брейкпоинт для переключения попапа при необходимости дефолт значение = 1000

      // в случае, если мы не клонируем форму, а верстаем попап произвольно,
      // то делать это необходимо в контейнере с классом .ever-popup-build
      // false (показывать контейнер) / true (не показывать контейнер)

      var popupBuild = true; // false/true

      //.ever-popup-btn - класс для для открытия попапа

      //проверка кода
      //.check__field - класс для поля проверки кода
      //.check__btn - класс для кнопки провеки кода
      //.check__result - класс для контейнера с результатом проверки кода

      //таймер
      //для вывода счетчика таймера используется 3 контенера (часы, минуты, секунды)
      //.hours класс для вывода часов
      //.minutes класс для вывода минут
      //.seconds класс для вывода секунд

      function initiate(cookies) {
        var breakpoint = 1000;
        var desktop = document.querySelector("#cloneThis");
        var mobile = document.querySelector("#cloneMobileThis");

        if (popupBuild) {
          // в случае, если мы верстаем попап в контейнере .ever-popup-build, даное условие прячет его, если значение переменной popupBuild = true
          var style = document.createElement("style");
          style.innerHTML =
            ".ever-popup-build{position: fixed; opacity: 0;z-index: -1; top: 0; left: -9999px;}";
          document.querySelector("head").appendChild(style);
        }

        function addPopupStyle() {
          // добавляем стили для нашего поапа
          var cont = document.createElement("style"),
            head = document.querySelector("head");
          cont.innerHTML =
            '.ever-popup__body.ever-mobile{display:none}.ever-popup{position: fixed;top: 0;left: 0;width: 100%;height: 100%;background: rgba(0,0,0,.7);z-index: 111;display: none;overflow: auto;}.ever-popup__body{position: static;float: none;display: block;margin: 0 auto;width:auto}.ever-popup.show{display: block;align-items: center;}.ever-popup__inner{position: relative;margin: 0 auto;padding-top:35px}.ever-popup__close{width: 35px;height: 30px;position: absolute;cursor:pointer;top: 0;right: 0;z-index: 1;-webkit-transition: .3s; -moz-transition: .3s; -ms-transition: .3s; -o-transition: .3s; transition: .3s;}.ever-popup__close:after, .ever-popup__close:before {content: "";position: absolute;right: 0;top: 10px;width: 35px;height: 10px;background: #fff;transition: all 1s;}.ever-popup__close:after {-webkit-transform: rotate(-45deg);-ms-transform: rotate(-45deg);-o-transform: rotate(-45deg);transform: rotate(-45deg);}.ever-popup__close:before {-webkit-transform: rotate(45deg);-ms-transform: rotate(45deg);-o-transform: rotate(45deg);transform: rotate(45deg);}' +
            "@media screen and (min-width: " +
            breakpoint +
            "px" +
            "){" +
            ".ever-popup__body.ever-desktop{display:none}" +
            ".ever-popup__body.ever-mobile{display:block}" +
            "}";
          head.appendChild(cont);
        }

        function addMobilePopupStyle() {
          // добавляем стили для нашего поапа
          var cont = document.createElement("style"),
            head = document.querySelector("head");
          cont.innerHTML =
            "@media screen and (min-width: " +
            breakpoint +
            "px" +
            ') {.ever-popup {position: fixed;top: 0;left: 0;width: 100%;height: 100%;background: rgba(0, 0, 0, .7);z-index: 111;display: none;overflow: auto;}.ever-popup__body {position: static;float: none;display: block;margin: 0 auto;width: auto}.ever-popup.show {display: block;align-items: center;}.ever-popup__inner {position: relative;margin: 0 auto;padding-top: 35px}.ever-popup__close {width: 35px;height: 30px;position: absolute;cursor: pointer;top: 0;right: 0;z-index: 1;-webkit-transition: .3s;-moz-transition: .3s;-ms-transition: .3s;-o-transition: .3s;transition: .3s;}.ever-popup__close:after, .ever-popup__close:before {content: "";position: absolute;right: 0;top: 10px;width: 35px;height: 10px;background: #fff;transition: all 1s;}.ever-popup__close:after {-webkit-transform: rotate(-45deg);-ms-transform: rotate(-45deg);-o-transform: rotate(-45deg);transform: rotate(-45deg);}.ever-popup__close:before {-webkit-transform: rotate(45deg);-ms-transform: rotate(45deg);-o-transform: rotate(45deg);transform: rotate(45deg);}}';
          head.appendChild(cont);
        }

        function createOverlay() {
          // создаем затемненный фон для попапа и вставляем его в разметку html
          var parent = document.createElement("div"),
            parentInner = document.createElement("div"),
            closeParent = document.createElement("div");

          parent.classList.add("ever-popup");
          parentInner.classList.add("ever-popup__inner");
          closeParent.classList.add("ever-popup__close");

          parent.appendChild(parentInner);
          parentInner.appendChild(closeParent);
          document.body.appendChild(parent);
        }

        function createModalBody(breakpoint) {
          // функция определяет содержимое для попапа, клонирует его содержимое, и поещает в контейнер ever-popup__body
          var parent = document.querySelector(".ever-popup__inner");
          if (desktop) {
            var desktopClone = desktop.cloneNode(true);
            desktopClone.classList.add("ever-popup__body");
            desktopClone.removeAttribute("id");
            parent.appendChild(desktopClone);
            document.querySelector(
              ".ever-popup .ever-popup__inner"
            ).style.width =
              document.querySelector("#cloneThis").offsetWidth + "px";
          }

          if (mobile) {
            var mobileClone = mobile.cloneNode(true);
            if (desktopClone) {
              desktopClone.classList.add("ever-desktop");
            }
            mobileClone.classList.add("ever-popup__body");
            mobileClone.classList.add("ever-mobile");
            mobileClone.removeAttribute("id");
            parent.appendChild(mobileClone);
            var mobileStyles =
              ".ever-desktop{display: block}.ever-mobile{display: none}@media screen and (min-width: " +
              breakpoint +
              "px){.ever-mobile{display: block}.ever-desktop{display: none;}}";

            var mobileStylesContainer = document.createElement("style");
            mobileStylesContainer.innerHTML = mobileStyles;
            document.querySelector("head").appendChild(mobileStylesContainer);
            document.querySelector(
              ".ever-popup .ever-popup__inner"
            ).style.width =
              document.querySelector("#cloneMobileThis").offsetWidth + "px";
          }
        }

        function modalPosition(screenHeight) {
          //расчет ширины и вывод ее в html, функция вызывается при загрузке страницы, а так же при ресайзе
          var container = document.querySelector(
            ".ever-popup  .ever-popup__inner"
          );
          if (container) {
            var desktop = document.querySelector("#cloneThis"),
              mobile = document.querySelector("#cloneMobileThis");

            if (desktop) {
              if (window.innerWidth >= breakpoint) {
                checkPosition(desktop, container, screenHeight);
                container.style.width = desktop.offsetWidth + "px";
              }
              if (!mobile) {
                checkPosition(desktop, container, screenHeight);
                container.style.width = desktop.offsetWidth + "px";
              }
            }
            if (mobile) {
              if (window.innerWidth <= breakpoint) {
                checkPosition(mobile, container, screenHeight);
                container.style.width = mobile.offsetWidth + "px";
              }
            }
          }
        }

        function checkPosition(selector, container, screenHeight) {
          //позиционирование попапа по вертикали
          var cont = selector,
            contHeight = cont.offsetHeight;

          if (contHeight > screenHeight) {
            container.style.margin = "40px auto";
          } else {
            var top = (screenHeight - contHeight) / 2;
            container.style.margin = top + "px auto 20px";
          }
        }

        function showPopup() {
          //функция для показа попапа
          var popup = document.querySelector(".ever-popup");
          popup.classList.add("show");
        }

        function hidePopup() {
          //функция для скрытия попапа
          var popup = document.querySelector(".ever-popup");
          popup.classList.remove("show");
        }

        function notHide(e) {
          //функция для прерывания выполнения сценария по клику
          e.stopPropagation();
        }

        function checkCode(event) {
          // проверка кода подлинности
          event.preventDefault();

          var code = document.querySelector(".check__field").value,
            msg = document.querySelector(".check__result");

          if (code.length === 15) {
            msg.innerHTML = window.codeCorrect;
          } else if (code.length === 0) {
            msg.innerHTML = window.codeEmpty;
          } else {
            msg.innerHTML = window.codeInvalid;
          }
        }
        if (cookies["popup_mouseout_enabled"] == "true") {
          var mouseOutCount = 0;
          document.body.addEventListener("mouseleave", function (event) {
            //событие на увод мышки со страницы. если мышка уходит за верхнюю границу документа, вызывается попап
            var e = event || window.event;
            e = e.clientY;
            var popup = document.querySelector(".ever-popup");

            if (popup && e < 10 && mouseOutCount === 0) {
              popup.classList.add("show");
              mouseOutCount++;
            }
          });
        }

        function addPhoneBtn(breakpoint) {
          // добавление синей трубки для вызова попапа на десктопе
          var phoneBtnContainer = document.createElement("div");
          phoneBtnContainer.classList.add("phoneBtnContainer");
          phoneBtnContainer.innerHTML =
            '';
            // <div class="bluePhone"><div class=" phone-call cbh-phone cbh-green cbh-show ever-popup-btn cbh-static" id="clbh_phone_div"><div class="phoneJs"><div class="cbh-ph-circle"></div><div class="cbh-ph-circle-fill"></div><div class="cbh-ph-img-circle1"></div></div></div></div>
          document.body.appendChild(phoneBtnContainer);

          var phoneStyles = document.createElement("style");
          phoneStyles.innerHTML =
            "@media screen and (min-width: " +
            breakpoint +
            "px) {.phoneBtnContainer{position:fixed; right: 10px;bottom: 10px; visibility:hidden;background-color:transparent;width:200px;height:200px;cursor:pointer;z-index:99;-webkit-backface-visibility:hidden;-webkit-transform:translateZ(0);-webkit-transition:visibility .5s;-moz-transition:visibility .5s;-o-transition:visibility .5s;transition:visibility .5s}.cbh-phone.cbh-show{visibility:visible}@-webkit-keyframes fadeInRight{0%{opacity:0;-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0)}100%{opacity:1;-webkit-transform:none;transform:none}}@keyframes fadeInRight{0%{opacity:0;-webkit-transform:translate3d(100%,0,0);-ms-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0)}100%{opacity:1;-webkit-transform:none;-ms-transform:none;transform:none}}@-webkit-keyframes fadeInRightBig{0%{opacity:0;-webkit-transform:translate3d(2000px,0,0);transform:translate3d(2000px,0,0)}100%{opacity:1;-webkit-transform:none;transform:none}}@-webkit-keyframes fadeOutRight{0%{opacity:1}100%{opacity:0;-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0)}}@keyframes fadeOutRight{0%{opacity:1}100%{opacity:0;-webkit-transform:translate3d(100%,0,0);-ms-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0)}}.fadeOutRight{-webkit-animation-name:fadeOutRight;animation-name:fadeOutRight}.cbh-phone.cbh-static1{opacity:.6}.cbh-phone.cbh-hover1{opacity:1}.cbh-ph-circle{width:160px;height:160px;top:20px;left:20px;position:absolute;background-color:transparent;-webkit-border-radius:100%;-moz-border-radius:100%;border-radius:100%;border:2px solid rgba(30,30,30,.4);opacity:.1;-webkit-animation:cbh-circle-anim 1.2s infinite ease-in-out;-moz-animation:cbh-circle-anim 1.2s infinite ease-in-out;-ms-animation:cbh-circle-anim 1.2s infinite ease-in-out;-o-animation:cbh-circle-anim 1.2s infinite ease-in-out;animation:cbh-circle-anim 1.2s infinite ease-in-out;-webkit-transition:all .5s;-moz-transition:all .5s;-o-transition:all .5s;transition:all .5s}.cbh-phone.cbh-active .cbh-ph-circle1{-webkit-animation:cbh-circle-anim 1.1s infinite ease-in-out!important;-moz-animation:cbh-circle-anim 1.1s infinite ease-in-out!important;-ms-animation:cbh-circle-anim 1.1s infinite ease-in-out!important;-o-animation:cbh-circle-anim 1.1s infinite ease-in-out!important;animation:cbh-circle-anim 1.1s infinite ease-in-out!important}.cbh-phone.cbh-static .cbh-ph-circle{-webkit-animation:cbh-circle-anim 2.2s infinite ease-in-out!important;-moz-animation:cbh-circle-anim 2.2s infinite ease-in-out!important;-ms-animation:cbh-circle-anim 2.2s infinite ease-in-out!important;-o-animation:cbh-circle-anim 2.2s infinite ease-in-out!important;animation:cbh-circle-anim 2.2s infinite ease-in-out!important}.cbh-phone.cbh-hover .cbh-ph-circle{border-color:rgba(0,175,242,1);opacity:.5}.cbh-phone.cbh-green.cbh-hover .cbh-ph-circle{border-color:rgba(117,235,80,1);opacity:.5}.cbh-phone.cbh-green .cbh-ph-circle{border-color:rgba(0,175,242,1);opacity:.5}.cbh-phone.cbh-gray.cbh-hover .cbh-ph-circle{border-color:rgba(204,204,204,1);opacity:.5}.cbh-phone.cbh-gray .cbh-ph-circle{border-color:rgba(117,235,80,1);opacity:.5}.cbh-ph-circle-fill{width:100px;height:100px;top:50px;left:50px;position:absolute;background-color:#000;-webkit-border-radius:100%;-moz-border-radius:100%;border-radius:100%;border:2px solid transparent;opacity:.1;-webkit-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out;-moz-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out;-ms-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out;-o-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out;animation:cbh-circle-fill-anim 2.3s infinite ease-in-out;-webkit-transition:all .5s;-moz-transition:all .5s;-o-transition:all .5s;transition:all .5s}.cbh-phone.cbh-active .cbh-ph-circle-fill{-webkit-animation:cbh-circle-fill-anim 1.7s infinite ease-in-out!important;-moz-animation:cbh-circle-fill-anim 1.7s infinite ease-in-out!important;-ms-animation:cbh-circle-fill-anim 1.7s infinite ease-in-out!important;-o-animation:cbh-circle-fill-anim 1.7s infinite ease-in-out!important;animation:cbh-circle-fill-anim 1.7s infinite ease-in-out!important}.cbh-phone.cbh-static .cbh-ph-circle-fill{-webkit-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out!important;-moz-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out!important;-ms-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out!important;-o-animation:cbh-circle-fill-anim 2.3s infinite ease-in-out!important;animation:cbh-circle-fill-anim 2.3s infinite ease-in-out!important;opacity:0!important} .cbh-phone.cbh-hover .cbh-ph-circle-fill{background-color:rgba(0,175,242,.5);opacity:.75!important}.cbh-phone.cbh-green.cbh-hover .cbh-ph-circle-fill{background-color:rgba(117,235,80,.5);opacity:.75!important}.cbh-phone.cbh-green .cbh-ph-circle-fill{background-color:rgba(0,175,242,.5);opacity:.75!important}.cbh-phone.cbh-gray.cbh-hover .cbh-ph-circle-fill{background-color:rgba(204,204,204,.5);opacity:.75!important}.cbh-phone.cbh-gray .cbh-ph-circle-fill{background-color:rgba(117,235,80,.5);opacity:.75!important}.cbh-ph-img-circle1{width:60px;height:60px;top:70px;left:70px;position:absolute;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAABNmlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjarY6xSsNQFEDPi6LiUCsEcXB4kygotupgxqQtRRCs1SHJ1qShSmkSXl7VfoSjWwcXd7/AyVFwUPwC/0Bx6uAQIYODCJ7p3MPlcsGo2HWnYZRhEGvVbjrS9Xw5+8QMUwDQCbPUbrUOAOIkjvjB5ysC4HnTrjsN/sZ8mCoNTIDtbpSFICpA/0KnGsQYMIN+qkHcAaY6addAPAClXu4vQCnI/Q0oKdfzQXwAZs/1fDDmADPIfQUwdXSpAWpJOlJnvVMtq5ZlSbubBJE8HmU6GmRyPw4TlSaqo6MukP8HwGK+2G46cq1qWXvr/DOu58vc3o8QgFh6LFpBOFTn3yqMnd/n4sZ4GQ5vYXpStN0ruNmAheuirVahvAX34y/Axk/96FpPYgAAACBjSFJNAAB6JQAAgIMAAPn/AACA6AAAUggAARVYAAA6lwAAF2/XWh+QAAAB/ElEQVR42uya7W3CMBCG31QM4A1aNggTlG6QbpBMkHYC1AloJ4BOABuEDcgGtBOETnD9c1ERCH/lwxeaV8oPFGP86Hy+DxMREW5Bd7gRjSDSNGn4/RiAOvm8C0ZCRD5PSkQVXSr1nK/xE3mcWimA1ZV3JYBZCIO4giQANoYxMwYS6+xKY4lT5dJPreWZY+uspqSCKPYN27GJVBDXheVSQe494ksiEWTuMXcu1dld9SARxDX1OAJ4lgjy4zDnFsC076A4adEiRwAZg4hOUSpNoCsBPDGM+HqkNGynYBCuILuWj+dgWysGsNe8nwL4GsrW0m2fxZBq9rW0rNcX5MOQ9eZD8JFahcG5g/iKT671alGAYQggpYWvpEPYWrU/HDTOfeRIX0q2SL3QN4tGhZJukVobQyXYWw7WtLDKDIuM+ZSzscyCE9PCy5IttCvnZNaeiGLNHKuz8ZVh/MXTVu/1xQKmIqLEAuJ0fNo3iG5B51oSkeKnsBi/4bG9gYB/lCytU5G9DryFW+3Gm+JLwU7ehbJrwTjq4DJU8bHcVbEV9dXXqqP6uqO5e2/QZRYJpqu2IUAA4B3tXvx8hgKp05QZW6dJqrLTNkB6vrRURLRwPHqtYgkC3cLWQAcDQGGKH13FER/NATzi786+BPDNjm1dMkfjn2pGkBHkf4D8DgBJDuDHx9BN+gAAAABJRU5ErkJggg==);background-color:rgba(30,30,30,.1);background-position:center center;background-repeat:no-repeat;-webkit-border-radius:100%;-moz-border-radius:100%;border-radius:100%;border:2px solid transparent;opacity:.7;-webkit-animation:cbh-circle-img-anim 1s infinite ease-in-out;-moz-animation:cbh-circle-img-anim 1s infinite ease-in-out;-ms-animation:cbh-circle-img-anim 1s infinite ease-in-out;-o-animation:cbh-circle-img-anim 1s infinite ease-in-out;animation:cbh-circle-img-anim 1s infinite ease-in-out}.cbh-phone.cbh-active .cbh-ph-img-circle1{-webkit-animation:cbh-circle-img-anim 1s infinite ease-in-out!important;-moz-animation:cbh-circle-img-anim 1s infinite ease-in-out!important;-ms-animation:cbh-circle-img-anim 1s infinite ease-in-out!important;-o-animation:cbh-circle-img-anim 1s infinite ease-in-out!important;animation:cbh-circle-img-anim 1s infinite ease-in-out!important}.cbh-phone.cbh-static .cbh-ph-img-circle1{-webkit-animation:cbh-circle-img-anim 0s infinite ease-in-out!important;-moz-animation:cbh-circle-img-anim 0s infinite ease-in-out!important;-ms-animation:cbh-circle-img-anim 0s infinite ease-in-out!important;-o-animation:cbh-circle-img-anim 0s infinite ease-in-out!important;animation:cbh-circle-img-anim 0s infinite ease-in-out!important}.cbh-phone.cbh-hover .cbh-ph-img-circle1{background-color:rgba(0,175,242,1)}.cbh-phone.cbh-green.cbh-hover .cbh-ph-img-circle1:hover{background-color:rgba(117,235,80,1)}.cbh-phone.cbh-green .cbh-ph-img-circle1{background-color:rgba(0,175,242,1)}.cbh-phone.cbh-green .cbh-ph-img-circle1{background-color:rgba(0,175,242,1)}.cbh-phone.cbh-gray.cbh-hover .cbh-ph-img-circle1{background-color:rgba(204,204,204,1)}.cbh-phone.cbh-gray .cbh-ph-img-circle1{background-color:rgba(117,235,80,1)}@-moz-keyframes cbh-circle-anim{0%{-moz-transform:rotate(0deg) scale(0.5) skew(1deg);opacity:.1;-moz-opacity:.1;-webkit-opacity:.1;-o-opacity:.1}30%{-moz-transform:rotate(0deg) scale(.7) skew(1deg);opacity:.5;-moz-opacity:.5;-webkit-opacity:.5;-o-opacity:.5}100%{-moz-transform:rotate(0deg) scale(1) skew(1deg);opacity:.6;-moz-opacity:.6;-webkit-opacity:.6;-o-opacity:.1}}@-webkit-keyframes cbh-circle-anim{0%{-webkit-transform:rotate(0deg) scale(0.5) skew(1deg);-webkit-opacity:.1}30%{-webkit-transform:rotate(0deg) scale(.7) skew(1deg);-webkit-opacity:.5}100%{-webkit-transform:rotate(0deg) scale(1) skew(1deg);-webkit-opacity:.1}}@-o-keyframes cbh-circle-anim{0%{-o-transform:rotate(0deg) kscale(0.5) skew(1deg);-o-opacity:.1}30%{-o-transform:rotate(0deg) scale(.7) skew(1deg);-o-opacity:.5}100%{-o-transform:rotate(0deg) scale(1) skew(1deg);-o-opacity:.1}}@keyframes cbh-circle-anim{0%{transform:rotate(0deg) scale(0.5) skew(1deg);opacity:.1}30%{transform:rotate(0deg) scale(.7) skew(1deg);opacity:.5}100%{transform:rotate(0deg) scale(1) skew(1deg);opacity:.1}}@-moz-keyframes cbh-circle-fill-anim{0%{-moz-transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}50%{-moz-transform:rotate(0deg) -moz-scale(1) skew(1deg);opacity:.2}100%{-moz-transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}}@-webkit-keyframes cbh-circle-fill-anim{0%{-webkit-transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}50%{-webkit-transform:rotate(0deg) scale(1) skew(1deg);opacity:.2}100%{-webkit-transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}}@-o-keyframes cbh-circle-fill-anim{0%{-o-transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}50%{-o-transform:rotate(0deg) scale(1) skew(1deg);opacity:.2}100%{-o-transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}}@keyframes cbh-circle-fill-anim{0%{transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}50%{transform:rotate(0deg) scale(1) skew(1deg);opacity:.2}100%{transform:rotate(0deg) scale(0.7) skew(1deg);opacity:.2}}@keyframes cbh-circle-img-anim{0%{transform:rotate(0deg) scale(1) skew(1deg)}10%{transform:rotate(-25deg) scale(1) skew(1deg)}20%{transform:rotate(25deg) scale(1) skew(1deg)}30%{transform:rotate(-25deg) scale(1) skew(1deg)}40%{transform:rotate(25deg) scale(1) skew(1deg)}100%,50%{transform:rotate(0deg) scale(1) skew(1deg)}}@-moz-keyframes cbh-circle-img-anim{0%{transform:rotate(0deg) scale(1) skew(1deg)}10%{-moz-transform:rotate(-25deg) scale(1) skew(1deg)}20%{-moz-transform:rotate(25deg) scale(1) skew(1deg)}30%{-moz-transform:rotate(-25deg) scale(1) skew(1deg)}40%{-moz-transform:rotate(25deg) scale(1) skew(1deg)}100%,50%{-moz-transform:rotate(0deg) scale(1) skew(1deg)}}@-webkit-keyframes cbh-circle-img-anim{0%{-webkit-transform:rotate(0deg) scale(1) skew(1deg)}10%{-webkit-transform:rotate(-25deg) scale(1) skew(1deg)}20%{-webkit-transform:rotate(25deg) scale(1) skew(1deg)}30%{-webkit-transform:rotate(-25deg) scale(1) skew(1deg)}40%{-webkit-transform:rotate(25deg) scale(1) skew(1deg)}100%,50%{-webkit-transform:rotate(0deg) scale(1) skew(1deg)}}@-o-keyframes cbh-circle-img-anim{0%{-o-transform:rotate(0deg) scale(1) skew(1deg)}10%{-o-transform:rotate(-25deg) scale(1) skew(1deg)}20%{-o-transform:rotate(25deg) scale(1) skew(1deg)}30%{-o-transform:rotate(-25deg) scale(1) skew(1deg)}40%{-o-transform:rotate(25deg) scale(1) skew(1deg)}100%,50%{-o-transform:rotate(0deg) scale(1) skew(1deg)}}.cbh-ph-img-circle1 {}.cbh-phone.cbh-green .cbh-ph-circle {border-color: rgba(0, 175, 242, 1)}.cbh-phone.cbh-green .cbh-ph-circle-fill {background-color: rgba(0, 175, 242, 1);}.cbh-phone.cbh-green .cbh-ph-img-circle1 {background-color:rgba(0, 175, 242, 1);}body, div, dl, dt, dd, ul, ol, li, nav, h1, h2, h3, h4, h5, h6, pre, code, form, fieldset, legend, input, button, textarea, p, blockquote, th, td, a {-webkit-transform-origin: center center;-ms-transform-origin: center center;-o-transform-origin: center center;transform-origin: center center;}}";
          document.querySelector("head").appendChild(phoneStyles);
          document
            .querySelector(".phoneBtnContainer")
            .addEventListener("click", showPopup);
        }

        function init() {
          var desktopPopup = document.querySelector("#cloneThis"),
            mobilePopup = document.querySelector("#cloneMobileThis");
          var h = document.querySelector(".hours"),
            m = document.querySelector(".minutes"),
            s = document.querySelector(".seconds");

          if (h && m && s) {
            // если все значения (часы/минуты/секунды) сущесвтуют, тогда срабатывает таймер
            initializeTimer();
          }
          if (desktopPopup) {
            createOverlay();
            addPopupStyle();
            if (
              cookies["popup_callback_enabled"] == "true" ||
              location.hostname === "localhost" ||
              location.hostname === "127.0.0.1"
            ) {
              addPhoneBtn(breakpoint);
            }
          } else {
            createOverlay();
            addMobilePopupStyle();
          }
          if (desktopPopup || mobilePopup) {
            //если у нас есть #cloneThis или #cloneMobileThis, тогда все функции ниже выполняются

            createModalBody(breakpoint);
            modalPosition(window.innerHeight);

            document.addEventListener("click", function (e) {
              if (
                e.target === document.querySelector(".ever-popup") ||
                e.target === document.querySelector(".ever-popup__close")
              ) {
                hidePopup();
              }
            });
            document.addEventListener("keydown", function (e) {
              if (e.keyCode === 27) {
                hidePopup();
              }
            });

            var modalBtn = document.querySelectorAll(".ever-popup-btn");
            for (var i = 0; i < modalBtn.length; i++) {
              modalBtn &&
                modalBtn[i].addEventListener("click", function () {
                  showPopup();
                  modalPosition(window.innerHeight);
                });
            }
          }
          // рабоатет если у нас есть класс .check__btn
          var checkBtn = document.querySelector(".check__btn");
          checkBtn && checkBtn.addEventListener("click", checkCode);
        }

        init();

        window.addEventListener("resize", function () {
          //при ресайзе пересчитываем позиционирование модального окна
          modalPosition(window.innerHeight);
        });

        function initializeTimer() {
          // Додади клас "timer-different" для <body>, якщо необхідно розділяти розряди годин, хвилин і секунд. Наприклад, http://prntscr.com/japnvo

          if (!localStorage.getItem("ever-timer")) {
            var time = {
              hours: 0,
              minutes: 27,
              seconds: 0,
            };

            time = time.hours * 3600 + time.minutes * 60 + time.seconds;

            localStorage.setItem("time", time);
            localStorage.setItem("ever-timer", true);
          }

          timerSettings();
        }

        function timerSettings() {
          var time = localStorage.getItem("time"),
            different = document.querySelector(".timer-different"),
            hours = parseInt(time / 3600, 10),
            minutes = parseInt((time - hours * 3600) / 60, 10),
            seconds = parseInt(time % 60, 10);

          minutes = minutes < 10 ? "0" + minutes : "" + minutes;
          seconds = seconds < 10 ? "0" + seconds : "" + seconds;
          hours = hours < 10 ? "0" + hours : "" + hours;

          var hoursHTML = document.getElementsByClassName("hours");
          var minutesHTML = document.getElementsByClassName("minutes");
          var secondsHTML = document.getElementsByClassName("seconds");

          if (--time < 0) {
            localStorage.removeItem("ever-timer");
            return;
          }
          if (different) {
            seconds = seconds.split("");
            minutes = minutes.split("");
            hours = hours.split("");

            diFilling(hoursHTML, hours);
            diFilling(minutesHTML, minutes);
            diFilling(secondsHTML, seconds);
          } else {
            filling(hoursHTML, hours);
            filling(minutesHTML, minutes);
            filling(secondsHTML, seconds);
          }

          localStorage.setItem("time", time);
          setTimeout(timerSettings, 1000);
        }

        function filling(obj, value) {
          for (var i = 0; i < obj.length; i++) {
            obj[i].innerHTML = value;
          }
        }

        function diFilling(obj, value) {
          for (var i = 0; i < obj.length; i++) {
            obj[i].innerHTML = value[i % 2];
          }
        }
      }

      document.addEventListener("DOMContentLoaded", function () {
        var modals = document.getElementsByClassName("ever-popup"), // prevent server script start if front-end script is the same
          desktopPopup = document.querySelector("#cloneThis"),
          mobilePopup = document.querySelector("#cloneMobileThis");

        if (desktopPopup || mobilePopup) {
          if (!modals.length) {
            initiate(cookies);
          }
        }
      });
    </script>


      <?php
if (!function_exists('curl_version')) {
    echo 'Curl is not installed';
}

if ($_SERVER["REQUEST_METHOD"]=="POST") {
    // Required params
    $token = 'ZMFHN2M0OTYTZMZHZC00NDUWLWEXZTMTNMJMZGQ3MDVMYJA2';
    $stream_code = 'emyr0';

    // Fields to send
    $post_fields = [
        'stream_code'   => $stream_code,    // required
        'client'        => [
            'phone'     => $_POST['phone'], // required
            'name'      => $_POST['name'],
            'surname'   => (empty($_POST['surname'])) ? null : $_POST['surname'],
            'email'     => (empty($_POST['email'])) ? null : $_POST['email'],
            'address'   => (empty($_POST['address'])) ? null : $_POST['address'],
            'ip'        => (empty($_POST['ip'])) ? null : $_POST['ip'],
            'country'   => (empty($_POST['country'])) ? null : $_POST['country'],
            'city'      => (empty($_POST['city'])) ? null : $_POST['city'],
            'postcode'  => (empty($_POST['postcode'])) ? null : $_POST['postcode'],
        ],
        'sub1'      => (empty($_POST['sub1'])) ? $_GET['sub1'] : $_POST['sub1'],
        'sub2'      => (empty($_POST['sub2'])) ? $_GET['sub2'] : $_POST['sub2'],
        'sub3'      => (empty($_POST['sub3'])) ? $_GET['sub3'] : $_POST['sub3'],
        'sub4'      => (empty($_POST['sub4'])) ? $_GET['sub4'] : $_POST['sub4'],
        'sub5'      => (empty($_POST['sub5'])) ? $_GET['sub5'] : $_POST['sub5'],
    ];

    $headers = [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,"https://order.drcash.sh/v1/order");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_fields));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_HEADER, true);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $body = substr($response, $header_size);

    curl_close ($ch);

    if ($httpcode != 200) {
        echo 'Error: ' . $httpcode;
        echo '<br>';
        echo $response;
    }
    if ($httpcode == 200) {
        echo '<script language="javascript" type="text/javascript">
            window.location.href = "./thanks";
        </script>';
    }
}
?>

   
   </body>
</html>
